package com.example.demo;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.example.demo.DAO.FrameDAO;

@Controller
public class HomeController {
	
	@Autowired
	private FrameService frame;
	
	@RequestMapping("/")
	public String home()	{
		return "home.jsp";
	}
	
	@RequestMapping("/game")
	public ModelAndView roll(@RequestParam String rolls)	{
		ModelAndView mv = new ModelAndView();
		
		Game  game = new Game();
		game = frame.addRoll(rolls);
		String s = frame.validation(rolls);
		if(s.length() > 0)	mv.addObject("error", s);
		mv.addObject("obj", game);
		mv.setViewName("game.jsp");
		return mv;
	}
}
