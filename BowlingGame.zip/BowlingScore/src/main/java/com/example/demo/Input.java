package com.example.demo;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

@Entity
public class Input {
	@Id
	private int id;
	private String roll;
	public int getId() {
		return id;
	}
	public Input() {
		roll = "";
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getRoll() {
		return roll;
	}
	public void setRoll(String roll) {
		this.roll = roll;
	}
	public Boolean empty()	{
		return roll.length() == 0;
	}
}
