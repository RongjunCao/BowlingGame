package com.example.demo.DAO;

import java.util.ArrayList;

import org.jboss.jandex.Indexer;
import org.springframework.data.repository.CrudRepository;

import com.example.demo.Frame;

import antlr.collections.List;

public interface FrameDAO extends CrudRepository<Frame, Integer> {
	public ArrayList<Frame>	findAll();
}
