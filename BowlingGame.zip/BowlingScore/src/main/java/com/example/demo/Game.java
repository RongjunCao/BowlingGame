package com.example.demo;
import java.util.ArrayList;

import com.example.demo.Frame;
import com.example.demo.Score;

public class Game {
	private ArrayList<Frame> frames;
	private ArrayList<Score> scores;
	private ArrayList<Input> input;

	public ArrayList<Frame> getFrames() {
		return frames;
	}
	public void setFrames(ArrayList<Frame> frames) {
		this.frames = frames;
	}
	public ArrayList<Score> getScores() {
		return scores;
	}
	public void setScores(ArrayList<Score> scores) {
		this.scores = scores;
	}
	public ArrayList<Input> getInput() {
		return input;
	}
	public void setInput(ArrayList<Input> input) {
		this.input = input;
	}
	public String print()	{
		String result = "";
		int total = 0;
		for(int i=0;i<frames.size();i++)	{
			result+= "Frame: " + frames.get(i).getId()+"    "
					+"Input: " + input.get(i).getRoll()+"    "
					+"Score: ";
			Boolean check = scores.get(i).isFixed();
			total+=scores.get(i).getS();
			if(check == false)	{
				int num = scores.get(i).getRemain();
				String s = "<span style=\"color:red\">" 
						+"Score Not avaliable until " + num + " more rolls/roll"
						+ "</span>";
				result+=s;
			}
			else	{
				result+=scores.get(i).getS();
			}
			result+= "<br>"+" Total Scores: " + total+"<br>";
		}
		return result;
	}
	public int currFrame()	{
		int n = frames.size();
		if(n== 0)	return 1;
		Boolean check = frames.get(n-1).getDone();
		if(check == true)	return n+1;
		else	return n;
	}
	public int rollLeft()	{
		int n = frames.size();
		int result = 0;
		if(n == 0)	return 2;
		if(frames.get(n-1).getDone() == false)	{
			result = frames.get(n-1).getRoll();
		}
		else	result = 2;
		return result;
		
	}
}
