package com.example.demo.DAO;

import java.util.ArrayList;

import org.springframework.data.repository.CrudRepository;

import com.example.demo.Input;

public interface InputDAO extends CrudRepository<Input, Integer>
{
	public ArrayList<Input>	findAll();
}
