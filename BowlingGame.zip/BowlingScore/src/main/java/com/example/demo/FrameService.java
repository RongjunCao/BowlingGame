package com.example.demo;
import java.util.ArrayList;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.DAO.FrameDAO;
import com.example.demo.DAO.InputDAO;
import com.example.demo.DAO.ScoreDAO;

import antlr.collections.List;

@Service
public class FrameService {
	@Autowired
	private FrameDAO fDAO;
	@Autowired
	private ScoreDAO sDAO;
	@Autowired
	private InputDAO iDAO;

	
	public Game addRoll(String s) {
		Game game = new Game();
		game.setFrames(fDAO.findAll());
		game.setInput(iDAO.findAll());
		game.setScores(sDAO.findAll());
		int n = game.getScores().size();
		ArrayList<String> arr = turns(s);
		
		if(validation(s).length()!=0)	return game;
		
		for(int i=0;i<arr.size();i++)	{
			game.setFrames(fDAO.findAll());
			String str = arr.get(i);
			Frame currF = new Frame();
			Score currS = new Score();
			Input currI = new Input();
			int score = 0;
			Boolean c;
			if(game.getFrames().size() > 0)	{
				c = game.getFrames().get(n-1).getDone();
			}
			else	c = true;
			if(c == false)	{
				currF = fDAO.findById(n).orElse(new Frame());
				currS = sDAO.findById(n).orElse(new Score());
				currI = iDAO.findById(n).orElse(new Input());
				score = help(str,currF,currS,currI,c,score);
				if(currF.getId() == 10)	{
					if(currS.getS() == 10 && str.equals("Spare"))	{
						if(currI.getRoll().length() == 3)	{
							currF.setDone(false);
							currF.setRoll(1);
						}
					}
				}
				fDAO.save(currF);
				sDAO.save(currS);
				iDAO.save(currI);
			}
			else	{
				score = help(str,currF,currS,currI,c,score);
				if(n == 9)	{
					if(currI.getRoll().equals("X"))	{
						currF.setDone(false);
						currF.setRoll(1);
					}
				}
				fDAO.save(currF);
				currS.setId(currF.getId());
				currI.setId(currF.getId());
				sDAO.save(currS);
				iDAO.save(currI);
				n++;
			}
			for(int j=1;j<n;j++)	{
				//if(n== j)	break;
				Score sc = sDAO.findById(j).orElse(new Score());
				if(sc.isFixed() == false)	{
					//sc = sDAO.findById(j).get();
					int num = sc.getRemain() - 1;
					sc.setRemain(num);
					if(num == 0)	sc.setFixed(true);
					int result = sc.getS()+score;
					sc.setS(result);
					sc = sDAO.save(sc);
				}
			}
		}
		game.setFrames(fDAO.findAll());
		game.setInput(iDAO.findAll());
		game.setScores(sDAO.findAll());
		return game;
	}
	public int help(String str, Frame currF,Score currS,Input currI,Boolean c,int score)	{
		if(str.equals("Strike"))	{
			currI.setRoll("X");
			currF.setDone(true);
			currF.setRoll(0);
			currS.setS(10);
			currS.setFixed(false);
			currS.setRemain(2);
			score = 10;
		}
		else if(str.equals("Spare")) {
			currI.setRoll(currI.getRoll()+" /");
			currF.setDone(true);
			currF.setRoll(0);
			score = 10- currS.getS();
			currS.setS(10);
			currS.setFixed(false);
			currS.setRemain(1);
		}
		else if(str.equals("Miss"))	{
			if(currI.empty())	{
				currI.setRoll("-");
				currF.setDone(false);
				currF.setRoll(1);
				currS.setS(0);
				currS.setFixed(true);
				currS.setRemain(0);
				score = 0;
			}
			else	{
				currI.setRoll(currI.getRoll()+" -");
				currF.setDone(true);
				currF.setRoll(0);
				score =  0;
				currS.setFixed(true);
				currS.setRemain(0);
			}
		}
		else	{
			score = Integer.parseInt(str);
			if(currI.empty())	{
				currI.setRoll(str);
				currF.setDone(false);
				currF.setRoll(1);
				currS.setS(score);
				currS.setFixed(true);
				currS.setRemain(0);
			}
			else	{
				currI.setRoll(currI.getRoll()+' '+str);
				currF.setDone(true);
				currF.setRoll(0);
				currS.setS(score+currS.getS());
				currS.setFixed(true);
				currS.setRemain(0);
			}
		}
		return score;
	}
	
	public ArrayList<String>  turns(String s)	{
		ArrayList<String> arr = new ArrayList();
		String t ="";
		for(int i=0;i<s.length();i++)	{
			if(s.charAt(i) == ' ')	continue;
			if(s.charAt(i) == ',')	{
				arr.add(t);
				t="";
			}
			else	{
				t+=s.charAt(i);
			}
		}
		if(!t.equals(""))	arr.add(t);
		return arr;
	}
	
	public String validation(String s)	{
		String result = "";
		ArrayList<String> arr = turns(s);
		if(arr.size()==0)	return result;
		Game game = new Game();
		game.setFrames(fDAO.findAll());
		game.setInput(iDAO.findAll());
		game.setScores(sDAO.findAll());
		int n = game.getScores().size();
		String inp1 = "";
		int inp2 = 0;
		if(n != 0)	{
			if(!game.getFrames().get(n-1).getDone())	{
				inp1 = game.getInput().get(n-1).getRoll();
				inp2 = game.getScores().get(n-1).getS();
			}
		}
		for(int i=0;i<arr.size();i++)	{
			String ss = arr.get(i);
			
			if(!ss.equals("Strike") && !ss.equals("Spare") &&!ss.equals("Miss"))	{
				if(ss.length() > 1)	{
					result = "You can only Enter either Strike,Spare,Miss, or a number less than 10";
					break;
				}
				int temp = (int)ss.charAt(0);
				if(temp < 48 || temp > 57)	{
					result = "You can only Enter either Strike,Spare,Miss, or a number less than 10";
					break;
				}
			}
			
			if(n > 10)	{
				result = "10 Frames for one game! Your input caused Frames over 10";
				break;
			}
			if(n == 10)	{
				if(game.getFrames().size() > 9)	{
					if(game.getFrames().get(9).getDone()==true)	{
						result = "10 Frames for one game! Your input caused Frames over 10";
						break;
					}
				}
				if(inp1.length() == 0)	{
					inp1=ss;
					if(ss.equals("Strike"))	inp2=10;
					else if(ss.equals("Miss"))	inp2 =0;
					else if(ss.equals("Spare"))	{
						result = "Spare can only happen in 2nd roll of any Frames!";
						break;
					}
					else	{
						int num = Integer.parseInt(ss);
						inp2=num;
					}
					continue;
				}
				else {
					if(ss.equals("Strike"))	{
						result = "Strike can only happen in 1st roll of any Frame!";
						break;
					}
					else if(ss.equals("Spare"))	{
						if(inp1.equals("X"))	{
							result = "Spare can only happen in 2nd roll of any Frames!";
							break;
						}
						else if(inp1.contains("/"))	{
							result = "Spare can only happen in 2nd roll of any Frames!";
							break;
						}
						else	{
							inp1+="/";
							inp2 = 10;
							continue;
						}
					}
					else if(ss.equals("Miss"))	{
						n++;
						continue;
					}
					else	{
						if(inp1.equals("X") || inp1.contains("/")|| inp1.equals("-"))	{
							n++;
							continue;
						}
						else	{
							int num = Integer.parseInt(ss);
							if(num + inp2 > 9)	{
								result ="Invalid numbers of pins knocked down(Maximum 10),if all the remaining were knocked down"
										+ ",please Enter Spare instead";
								break;
							}
							else	{
								n++;
								continue;
							}
						}
					}
				}
			}
			if(ss.equals("Miss"))	{
				if(inp1.length()==0)	{
					inp1 = "-";
					continue;
				}
				else	{
					inp1 = "";
					inp2 = 0;
					n++;
					continue;
				}
			}
			if(ss.equals("Spare"))	{
				if(inp1.length() == 0)	{
					result = "Spare can only happen in 2nd roll of any Frames!";
					break;
				}
				else	{
					inp1 ="";
					inp2=0;
					n++;
					continue;
				}
			}
			if(ss.equals("Strike"))	{
				if(inp1.length() != 0)	{
					result = "Strike can only happen in 1st roll of any Frame!";
					break;
				}
				else	{
					n++;
					continue;
				}
			}
			int num = Integer.parseInt(ss);
			if(inp1.length() == 0)	{
				inp1 = ss;
				inp2 = num;
				continue;
			}
			else	{
				if(inp2+num > 9)	{
					result ="Invalid numbers of pins knocked down(Maximum 10),if all the remaining were knocked down"
							+ ",please Enter Spare instead";
					break;
				}
				else	{
					n++;
					inp1 ="";
					inp2=0;
					continue;
				}
			}
		}
		return result;
	}
	
	public FrameDAO getfDAO() {
		return fDAO;
	}


	public void setfDAO(FrameDAO fDAO) {
		this.fDAO = fDAO;
	}

	public ScoreDAO getsDAO() {
		return sDAO;
	}

	public void setsDAO(ScoreDAO sDAO) {
		this.sDAO = sDAO;
	}

	public InputDAO getiDAO() {
		return iDAO;
	}

	public void setiDAO(InputDAO iDAO) {
		this.iDAO = iDAO;
	}
	
}
